<?
	// Only output on full page loads
	if (!$isASAP) {
?>
							</div>
						</article>
					</div>
				</div>
			</div>
		</div>
		<footer class="footer">
			<div class="fs-row">
				<div class="fs-cell-centered fs-lg-10">
					<p>&copy; 2015 &nbsp;&middot;&nbsp; A Project By <a href="http://benplum.com/" target="_blank">Ben Plum</a></p>
				</div>
			</div>
		</footer>
	</body>
</html>
<?
	}
	// END: Only output on full page loads
?>